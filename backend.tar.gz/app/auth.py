"""
Módulo de autenticação Azure DevOps.
Suporta autenticação via:
- Personal Access Token (PAT) para desenvolvimento
- Bearer OAuth Token (do SDK Azure DevOps) para produção em iframe
"""

import base64
import json
import logging
import httpx
import re
from fastapi import Depends, HTTPException, Request, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from app.config import get_settings

# Configurar logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

settings = get_settings()

# Security scheme para Swagger UI
security = HTTPBearer(auto_error=False)


class AzureDevOpsUser:
    """Representa um usuário autenticado do Azure DevOps."""

    def __init__(
        self,
        id: str,
        display_name: str,
        email: str | None = None,
        token: str | None = None,
    ):
        self.id = id
        self.display_name = display_name
        self.email = email
        self.token = token

    def __repr__(self) -> str:
        return f"<AzureDevOpsUser(id={self.id}, name='{self.display_name}')>"


async def validate_azure_token(
    request: Request,
    credentials: HTTPAuthorizationCredentials | None = Depends(security),
) -> AzureDevOpsUser:
    """
    Valida token de autenticação Azure DevOps.

    Suporta:
    - Basic auth com PAT (para desenvolvimento/testes)

    Quando AUTH_ENABLED=false, retorna usuário mock para desenvolvimento.
    """
    # Modo desenvolvimento sem autenticação
    if not settings.auth_enabled:
        logger.info("Auth desabilitada - tentando obter usuário via PAT")
        dev_token = settings.azure_devops_pat or ""
        if dev_token:
            user_info, _ = await _fetch_user_profile(dev_token)
            if user_info:
                _apply_custom_header_user_info(user_info, request)
                return user_info

        logger.info("Auth desabilitada - retornando usuário mock")
        return AzureDevOpsUser(
            id="dev-user-001",
            display_name="Dev User",
            email="dev@localhost",
            token=dev_token,
        )

    # Verificar se credentials foram fornecidas
    if not credentials:
        logger.warning("Nenhuma credencial fornecida")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token de autenticação não fornecido",
            headers={"WWW-Authenticate": "Bearer"},
        )

    token = credentials.credentials
    scheme = credentials.scheme.lower()  # 'bearer' ou 'basic'
    logger.debug(f"Token recebido (scheme={scheme}, primeiros 10 chars): {token[:10]}...")

    # Detectar tipo de autenticação:
    # - Bearer: Token OAuth do SDK Azure DevOps (produção/iframe)
    # - Basic: PAT codificado em base64 (desenvolvimento)
    # - Bearer com PAT: Também suportado para flexibilidade
    is_bearer = scheme == "bearer"
    
    # Validar token (Bearer OAuth ou PAT)
    user_info, error_msg = await _fetch_user_profile(token, is_bearer=is_bearer)

    if not user_info:
        logger.error(f"Falha na autenticação: {error_msg}")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=f"Token inválido ou expirado. Detalhes: {error_msg}",
            headers={"WWW-Authenticate": "Bearer"},
        )

    logger.info(f"Usuário autenticado: {user_info.display_name}")
    _apply_custom_header_user_info(user_info, request)
    return user_info


async def _fetch_user_profile(
    token: str, is_bearer: bool = False
) -> tuple[AzureDevOpsUser | None, str]:
    """
    Busca perfil do usuário na API do Azure DevOps.
    
    Args:
        token: Token de autenticação (PAT ou Bearer OAuth)
        is_bearer: Se True, usa Bearer auth (OAuth do SDK).
                   Se False, usa Basic auth (PAT).
    
    Tenta validar usando connectionData na organização (se configurada)
    ou no profile global.
    """
    # Determinar URL de validação
    if settings.azure_devops_org_url:
        org_url = settings.azure_devops_org_url.rstrip("/")
        validation_url = f"{org_url}/_apis/connectionData?api-version=7.1-preview.1"
    else:
        validation_url = "https://app.vssps.visualstudio.com/_apis/profile/profiles/me?api-version=7.1-preview.1"

    profile_url = _build_profile_url(settings.azure_devops_org_url)

    async with httpx.AsyncClient(timeout=10.0) as client:
        # Montar header de autorização baseado no tipo de token
        if is_bearer:
            # Bearer OAuth (token do SDK Azure DevOps)
            auth_header = f"Bearer {token}"
            logger.debug("Usando Bearer OAuth para autenticação")
        else:
            # Basic Auth com PAT
            pat_encoded = base64.b64encode(f":{token}".encode()).decode()
            auth_header = f"Basic {pat_encoded}"
            logger.debug("Usando Basic Auth (PAT) para autenticação")

        try:
            # Validar token
            response = await client.get(
                validation_url, headers={"Authorization": auth_header}
            )

            if response.status_code == 200:
                data = response.json()
                if "authenticatedUser" in data:
                    user = data["authenticatedUser"]
                    display_name = user.get(
                        "providerDisplayName",
                        user.get("customDisplayName", "Unknown"),
                    )
                    profile_name = await _fetch_profile_display_name(
                        client, token, profile_url, is_bearer=is_bearer
                    )
                    if profile_name:
                        display_name = profile_name
                    elif display_name:
                        display_name = _maybe_normalize_display_name(
                            display_name,
                            user.get("properties", {})
                            .get("Account", {})
                            .get("$value"),
                        )
                    return (
                        AzureDevOpsUser(
                            id=user.get("id", ""),
                            display_name=display_name,
                            email=user.get("properties", {})
                            .get("Account", {})
                            .get("$value"),
                            token=token,
                        ),
                        "",
                    )
                else:
                    display_name = data.get("displayName", "Unknown")
                    profile_name = await _fetch_profile_display_name(
                        client, token, profile_url, is_bearer=is_bearer
                    )
                    if profile_name:
                        display_name = profile_name
                    elif display_name:
                        display_name = _maybe_normalize_display_name(
                            display_name,
                            data.get("emailAddress"),
                        )
                    return (
                        AzureDevOpsUser(
                            id=data.get("id", ""),
                            display_name=display_name,
                            email=data.get("emailAddress"),
                            token=token,
                        ),
                        "",
                    )

            # Falha final
            error_body = response.text[:200] if response.text else "Sem corpo"
            logger.warning(
                f"Falha auth na URL {validation_url}: Status {response.status_code}"
            )
            return None, f"Status {response.status_code}: {error_body}"

        except httpx.TimeoutException:
            return None, "Timeout ao conectar com Azure DevOps"
        except Exception as e:
            logger.error(f"Erro na validação do token: {str(e)}")
            return None, f"Erro de conexão: {str(e)}"


def _build_profile_url(org_url: str | None) -> str:
    """Monta a URL do Profile API para obter o displayName completo."""
    if not org_url:
        return "https://app.vssps.visualstudio.com/_apis/profile/profiles/me?api-version=7.1-preview.1"

    match = re.search(r"dev\.azure\.com/([^/]+)", org_url)
    if match:
        org = match.group(1)
        return f"https://vssps.dev.azure.com/{org}/_apis/profile/profiles/me?api-version=7.1-preview.1"

    return "https://app.vssps.visualstudio.com/_apis/profile/profiles/me?api-version=7.1-preview.1"


def _apply_custom_header_user_info(
    user_info: AzureDevOpsUser, request: Request | None
) -> None:
    """Sobrescreve displayName/email com dados do header x-custom-header (base64 JSON)."""
    if not request:
        return

    raw_header = request.headers.get("x-custom-header")
    if not raw_header:
        return

    try:
        decoded = base64.b64decode(raw_header).decode("utf-8")
        payload = json.loads(decoded)
    except Exception:
        return

    full_name = payload.get("User-Name")
    if full_name:
        user_info.display_name = full_name

    email = payload.get("User-Email")
    if email and not user_info.email:
        user_info.email = email


def _maybe_normalize_display_name(display_name: str, email: str | None) -> str:
    """Normaliza displayName usando o email quando o nome parece um identificador curto."""
    if not email:
        return display_name

    has_space = " " in display_name
    looks_like_code = display_name.isalnum() and len(display_name) <= 12
    if has_space or not looks_like_code:
        return display_name

    local_part = email.split("@", 1)[0].strip()
    if not local_part:
        return display_name

    normalized = (
        local_part.replace(".", " ")
        .replace("_", " ")
        .replace("-", " ")
    )
    normalized = " ".join(segment.capitalize() for segment in normalized.split())
    return normalized or display_name


async def _fetch_profile_display_name(
    client: httpx.AsyncClient, token: str, profile_url: str, is_bearer: bool = False
) -> str | None:
    """Tenta obter displayName completo via Profile API."""
    if not profile_url:
        return None

    # Montar header de autorização baseado no tipo de token
    if is_bearer:
        auth_header = f"Bearer {token}"
    else:
        pat_encoded = base64.b64encode(f":{token}".encode()).decode()
        auth_header = f"Basic {pat_encoded}"

    try:
        response = await client.get(
            profile_url, headers={"Authorization": auth_header}
        )
        if response.status_code == 200:
            data = response.json()
            name = data.get("displayName")
            if name:
                return name
    except httpx.TimeoutException:
        return None
    except Exception:
        return None

    return None


def get_current_user(
    user: AzureDevOpsUser = Depends(validate_azure_token),
) -> AzureDevOpsUser:
    """Dependency para obter usuário atual autenticado."""
    return user
