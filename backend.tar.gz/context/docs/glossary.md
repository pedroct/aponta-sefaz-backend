# Glossario

- **Atividade**: unidade de trabalho gerenciada pela API.
- **Projeto**: agrupador de atividades, sincronizado com Azure DevOps.
- **PAT**: Personal Access Token do Azure DevOps.
- **Health check**: endpoint para verificar disponibilidade.
- **Migration**: versionamento de schema via Alembic.
- **Schema**: conjunto de tabelas no PostgreSQL.
- **CORS**: politica de compartilhamento entre origens.
